import numpy as np
import cv2


def mutual_information(img1, img2):
    """
    Calcula la Información Mutua entre dos imágenes.

    Puede recibir:
        - rutas de archivos (str)
        - imágenes ya cargadas (numpy.ndarray)
    """

    # Si recibe rutas, carga las imágenes
    if isinstance(img1, str):
        img1 = cv2.imread(img1, cv2.IMREAD_GRAYSCALE)

    if isinstance(img2, str):
        img2 = cv2.imread(img2, cv2.IMREAD_GRAYSCALE)

    if img1 is None or img2 is None:
        raise ValueError("No se pudieron cargar las imágenes")

    vector1 = img1.flatten()
    vector2 = img2.flatten()

    hist_2d, _, _ = np.histogram2d(
        vector1,
        vector2,
        bins=256
    )

    p_xy = hist_2d / np.sum(hist_2d)

    p_x = np.sum(p_xy, axis=1)
    p_y = np.sum(p_xy, axis=0)

    p_x_p_y = np.outer(p_x, p_y)

    nonzero_mask = p_xy > 0

    mi = np.sum(
        p_xy[nonzero_mask]
        * np.log2(
            p_xy[nonzero_mask]
            / p_x_p_y[nonzero_mask]
        )
    )

    return mi