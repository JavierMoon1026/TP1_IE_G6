import cv2
import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage import shift
import ejercicio1


# =====================================================
# SUPERPOSICION
# =====================================================

def superponer(img_back, img_mask):

    fig, ax = plt.subplots()

    ax.imshow(img_back, cmap='gray')

    mask = img_mask > 0.1

    red_overlay = np.zeros((*img_mask.shape, 4))

    red_overlay[..., 0] = 1.0
    red_overlay[..., 3] = mask.astype(float)

    ax.imshow(red_overlay)

    ax.axis('off')

    plt.show()


# =====================================================
# CARGA DE IMAGENES
# =====================================================

img_ref = cv2.imread(
    "Imagenes/llaves.jpg",
    cv2.IMREAD_GRAYSCALE
)

img_patron = cv2.imread(
    "Imagenes/patron.jpg",
    cv2.IMREAD_GRAYSCALE
)

if img_ref is None:
    raise ValueError("No se encontró llaves.jpg")

if img_patron is None:
    raise ValueError("No se encontró patron.jpg")


# =====================================================
# REDUCCION PARA ACELERAR
# =====================================================

factor = 0.5

img_ref_small = cv2.resize(
    img_ref,
    None,
    fx=factor,
    fy=factor
)

img_patron_small = cv2.resize(
    img_patron,
    None,
    fx=factor,
    fy=factor
)


# =====================================================
# BUSQUEDA GRUESA
# =====================================================

io_values = np.arange(-80, 81, 8)
jo_values = np.arange(-80, 81, 8)

mi_matrix = np.zeros(
    (len(io_values), len(jo_values))
)

for i, io in enumerate(io_values):

    for j, jo in enumerate(jo_values):

        patron_shifted = shift(
            img_patron_small,
            shift=(io, jo),
            cval=0,
            order=0
        )

        mi_matrix[i, j] = ejercicio1.mutual_information(
            img_ref_small,
            patron_shifted
        )


# =====================================================
# HEATMAP
# =====================================================

plt.figure(figsize=(8, 6))

plt.imshow(
    mi_matrix,
    cmap="hot",
    origin="lower",
    extent=[
        jo_values[0],
        jo_values[-1],
        io_values[0],
        io_values[-1]
    ]
)

plt.colorbar(
    label="Información Mutua"
)

plt.xlabel("jo")
plt.ylabel("io")
plt.title("Mapa de calor")

plt.show()


# =====================================================
# MAXIMO
# =====================================================

indice_max = np.unravel_index(
    np.argmax(mi_matrix),
    mi_matrix.shape
)

i_max, j_max = indice_max

io_opt = io_values[i_max]
jo_opt = jo_values[j_max]

print("\nDesplazamiento óptimo encontrado:")
print("io =", io_opt)
print("jo =", jo_opt)

# volver a escala original

io_opt = int(io_opt / factor)
jo_opt = int(jo_opt / factor)

print("\nEscala original:")
print("io =", io_opt)
print("jo =", jo_opt)


# =====================================================
# ALINEACION FINAL
# =====================================================

patron_final = shift(
    img_patron,
    shift=(io_opt, jo_opt),
    cval=0,
    order=0
)

plt.figure(figsize=(8, 6))
plt.imshow(img_ref, cmap="gray")
plt.title("Imagen de referencia")
plt.axis("off")
plt.show()


plt.figure(figsize=(8, 6))
plt.imshow(patron_final, cmap="gray")
plt.title("Patrón alineado")
plt.axis("off")
plt.show()


superponer(
    img_ref,
    patron_final
)

# =====================================================
# EJERCICIO 3(c)
# DISCUSION DE RESULTADOS
# =====================================================

# Se observó que el máximo encontrado corresponde a una región con alta
# similitud respecto al patrón, aunque no necesariamente a la alineación
# visual exacta esperada. Esto refleja una limitación del método, ya que la
# información mutua mide dependencia estadística global entre las imágenes.